package Pracownicy_Uczelni;

import Uczelnia.Pracownik_Uczelni;

public class Pracownik_Badawczo_Dydaktyczny extends Pracownik_Uczelni {
    private int punktacjazDorobku;

    public Pracownik_Badawczo_Dydaktyczny(String imie, String nazwisko, String PESEL, int wiek, String plec, String stanowisko, int stazPracy, double pensja, int punktacjazDorobku) {
        super(imie, nazwisko, PESEL, wiek, plec, stanowisko, stazPracy, pensja);
        this.punktacjazDorobku = punktacjazDorobku;
    }

    public int getPunktacjazDorobku() {
        return punktacjazDorobku;
    }

    public void setPunktacjazDorobku(int punktacjazDorobku) {
        this.punktacjazDorobku = punktacjazDorobku;
    }
    public String toString(){
        System.out.println("----------------------------");
        System.out.println("PRACOWNIK BADAWCZO-DYDAKTYCZNY");
        return"Imie: "+getImie()+"\nNazwisko: "+getNazwisko()+"\nPESEL: "+getPESEL()+"\nWiek: "+getWiek()+"\nPłeć: "+getPlec()+"\nStanowisko:"+getStanowisko()+"\nStaż pracy: "+getStazPracy()+"\nPensja: "+getPensja()+"\nPunktacja z dorobku: "+punktacjazDorobku;
    }
}
