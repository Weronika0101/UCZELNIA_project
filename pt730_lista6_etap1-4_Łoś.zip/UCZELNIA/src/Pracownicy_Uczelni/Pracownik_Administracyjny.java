package Pracownicy_Uczelni;

import Uczelnia.Pracownik_Uczelni;

public class Pracownik_Administracyjny extends Pracownik_Uczelni {
    private int liczbaNadgodzin;

    public Pracownik_Administracyjny(String imie, String nazwisko, String PESEL, int wiek, String plec, String stanowisko, int stazPracy, double pensja, int liczbaNadgodzin) {
        super(imie, nazwisko, PESEL, wiek, plec, stanowisko, stazPracy, pensja);
        this.liczbaNadgodzin = liczbaNadgodzin;
    }

    public int getLiczbaNadgodzin() {
        return liczbaNadgodzin;
    }

    public void setLiczbaNadgodzin(int liczbaNadgodzin) {
        this.liczbaNadgodzin = liczbaNadgodzin;
    }
    public String toString(){
        System.out.println("----------------------------");
        System.out.println("PRACOWNIK ADMINISTRACYJNY");
        return"Imie: "+getImie()+"\nNazwisko: "+getNazwisko()+"\nPESEL: "+getPESEL()+"\nWiek: "+getWiek()+"\nPłeć: "+getPlec()+"\nStanowisko:"+getStanowisko()+"\nStaż pracy: "+getStazPracy()+"\nPensja: "+getPensja()+ "\nLiczba nadgodzin: "+liczbaNadgodzin;
    }
}
