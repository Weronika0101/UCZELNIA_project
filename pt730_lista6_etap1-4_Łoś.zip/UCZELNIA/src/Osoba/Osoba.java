package Osoba;


import Pracownicy_Uczelni.Pracownik_Administracyjny;
import Uczelnia.Pracownik_Uczelni;
import Uczelnia.Student;

import java.io.Serializable;
import java.util.ArrayList;

public abstract class Osoba implements Serializable {
    private String imie;
    private String nazwisko;
    private String PESEL;
    private int wiek;
    private String plec;

    public Osoba(String imie, String nazwisko, String PESEL, int wiek, String plec) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.PESEL = PESEL;
        this.wiek = wiek;
        this.plec = plec;
    }

    public String getImie() {
        return imie;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }

    public String getPESEL() {
        return PESEL;
    }

    public void setPESEL(String PESEL) {
        this.PESEL = PESEL;
    }

    public int getWiek() {
        return wiek;
    }

    public void setWiek(int wiek) {
        this.wiek = wiek;
    }

    public String getPlec() {
        return plec;
    }

    public void setPlec(String plec) {
        this.plec = plec;
    }

    public String toString() {
        return "Imie: " + imie + " Nazwisko: " + nazwisko + " PESEL: " + PESEL + " Wiek: " + wiek + " Płeć: " + plec;
    }

    //wyswietlanie informacji o wszystkich osobach z arrayList
    public static void wyswieltStudentow(ArrayList<Osoba> listaOsob) {
        for (int i = 0; i < listaOsob.size(); i++) {
            if (listaOsob.get(i) instanceof Student) {
                System.out.println(listaOsob.get(i));
            }
        }

    }
    public static void wyswieltPracownikow(ArrayList<Osoba> listaOsob) {
        for (int i = 0; i < listaOsob.size(); i++) {
            if (listaOsob.get(i) instanceof Pracownik_Uczelni) {
                System.out.println(listaOsob.get(i));
            }
        }

    }
}
