package Serializacja;

import Osoba.Osoba;

import java.io.*;
import java.util.ArrayList;

public class Serializacja {

    public void zapisDoPliku(ArrayList<Osoba> listaOsob) {
        try {
            FileOutputStream fo = new FileOutputStream("listaOsob.txt");
            ObjectOutputStream so = new ObjectOutputStream(fo);
            so.writeObject(listaOsob);
            so.close();
            fo.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void odczytZPliku(ArrayList<Osoba>listaOsob){
        ArrayList<Osoba> listazPliku;
        try{
            FileInputStream fis =new FileInputStream("listaOsob.txt");
            ObjectInputStream ois =new ObjectInputStream(fis);
            listazPliku=(ArrayList)ois.readObject();
            for(int i=0;i< listazPliku.size();i++) {
                System.out.println(listazPliku.get(i));
            }
            ois.close();
            fis.close();

        } catch(IOException | ClassNotFoundException ioe){
            ioe.printStackTrace();
        }
    }

}
