package pl.weronikalos;


import Kursy.Kursy;
import Osoba.Osoba;
import Pracownicy_Uczelni.Pracownik_Administracyjny;
import Pracownicy_Uczelni.Pracownik_Badawczo_Dydaktyczny;
import Serializacja.Serializacja;
import Sortowanie.Sortowanie;
import Uczelnia.Student;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;


public class Main {

    public static void main(String[] args) {

        Wyszukiwanie W = new Wyszukiwanie();
        Kursy K = new Kursy();

        ArrayList<Kursy> bazaKursow = new ArrayList<>();
        bazaKursow.add(new Kursy("Analiza matematyczna |", "Tomasz Wilk", 6));
        bazaKursow.add(new Kursy("Fizyka |", "Andrzej Kot", 4));
        bazaKursow.add(new Kursy("Algebra", "Barbara Kowalska", 6));
        bazaKursow.add(new Kursy("Technologie informacyjne", "Paulina Kowalczyk", 3));
        bazaKursow.add(new Kursy("Grafika inżynierska", "Karol Baranowski", 4));
        bazaKursow.add(new Kursy("Programowanie", "Andrzej Karaś", 5));


        ArrayList<Osoba> listaOsob = new ArrayList<>();
        Osoba pracownik_administracyjny1 = new Pracownik_Administracyjny("Benedykt", "Zimniak", "60052097633", 61, "mezczyzna", "Referent", 25, 4500, 15);
        Osoba pracownik_administracyjny2 = new Pracownik_Administracyjny("Jan", "Kowalski", "79120634544", 52, "mężczyzna", "Specjalista", 21, 4800, 10);
        Osoba pracownik_badawczo_dydaktyczny = new Pracownik_Badawczo_Dydaktyczny("Katarzyna", "Piechota", "73081557422", 48, "kobieta", "wykładowca", 20, 5500, 25);
        Osoba student1 = new Student("Andrzej", "Kowalski", "014723349", 21, "mezczyzna", "255867", false, 1,  true, bazaKursow.get(0), bazaKursow.get(4));
        Osoba student2 = new Student("Krzysztof", "Nowaczyk", "01220835759", 20, "mezczyzna", "266844", false, 1, true, bazaKursow.get(1), bazaKursow.get(3));
        Osoba student3 = new Student("Maja", "Andrzejewska", "1234567890", 20, "kobieta", "12345", false, 2, false, bazaKursow.get(2), bazaKursow.get(5));

        listaOsob.add(pracownik_administracyjny1);
        listaOsob.add(pracownik_administracyjny2);
        listaOsob.add(pracownik_badawczo_dydaktyczny);
        listaOsob.add(student1);
        listaOsob.add(student2);
        listaOsob.add(student3);

        Serializacja serializacja=new Serializacja();
        serializacja.zapisDoPliku(listaOsob);
        serializacja.odczytZPliku(listaOsob);

        Sortowanie sortowanie=new Sortowanie();
        sortowanie.generateComparators();
        sortowanie.sortujNazwiskami(listaOsob);
        sortowanie.sortujNazwiskamiiImionami(listaOsob);
        sortowanie.sortujNazwiskamiiWiekiem(listaOsob);
        sortowanie.sortujPunktami(bazaKursow);
        sortowanie.sortujProwadzacymi(bazaKursow);


        Scanner scan = new Scanner(System.in);
        while(true) {
            System.out.println("Witaj na uczelni! Jeśli chcesz:\n-wyświetlić dane wszystkich studentów---> wpisz 1\n-wyswietlić dane wszystkich pracowników---> wpisz 2\n-wyświetlić dane wszystkich kursów--->wpisz 3\n-przejść odrazu do wyszukiwania konkretnych osób/kursów--->wpisz 4");
            try {
                int wybor1 = scan.nextInt();
                if (wybor1 == 1 || wybor1 == 2 || wybor1 == 3 || wybor1 == 4) {
                    switch (wybor1) {
                        case 1:
                            Osoba.wyswieltStudentow(listaOsob);
                            break;
                        case 2:
                            Osoba.wyswieltPracownikow(listaOsob);
                            break;
                        case 3:
                            K.wyswietlanieWszystkichKursow(bazaKursow);
                            break;
                        case 4:
                            System.out.println("Nie wybrałeś opcji wyświetlenia");
                            break;
                    }
                } else {
                    System.out.println("Nieprawidłowy numer!");

                }
            } catch (InputMismatchException e) {
                System.out.println("NIE WPISAŁEŚ LICZBY CAŁKOWITEJ!!");
                System.exit(0);
            }


           /* int i = 0;
            while (i < 10) {*/
                System.out.println();
                System.out.println("Wybierz kogo/co chcesz wyszukać: \n-studenta--->wpisz 1\n-pracownika--->wpisz 2\n-kurs--->wpisz 3");
                try {
                    int wybor2 = scan.nextInt();
                    if (wybor2 == 1 || wybor2 == 2 || wybor2 == 3)
                        switch (wybor2) {
                            case 1:
                                try {
                                    System.out.println("WYBIERZ OPCJĘ WYSZUKIWANIA STUDENTÓW:\n" +
                                            "1.po imieniu\n2.po nazwisku\n3.pu numerze indeksu\n4.po stopniu");
                                    int wybor3 = scan.nextInt();
                                    if (wybor3 == 1 || wybor3 == 2 || wybor3 == 3 || wybor3 == 4) {
                                        switch (wybor3) {
                                            case 1:
                                                System.out.println("Wpisz imie:");
                                                String imie = scan.next();
                                                System.out.println("Czy chcesz usunąć tą osobę z listy?\n1.tak\n2.nie");
                                                int b=scan.nextInt();
                                                W.wyszukiwanieStudentaPoImieniu(listaOsob, imie,b);
                                                break;
                                            case 2:
                                                System.out.println("Wpisz nazwisko: ");
                                                String nazwisko = scan.next();
                                                System.out.println("Czy chcesz usunąć tą osobę z listy?\n1.tak\n2.nie");
                                                 b=scan.nextInt();
                                                W.wyszukiwanieStudentaPoNazwisku(listaOsob, nazwisko,b);
                                                break;
                                            case 3:
                                                System.out.println("Wpisz numer indeksu: ");
                                                String nr_indeksu = scan.next();
                                                System.out.println("Czy chcesz usunąć tą osobę z listy?\n1.tak\n2.nie");
                                                b=scan.nextInt();
                                                W.wyszukiwanieStudentaPoNumerzeIndeksu(listaOsob, nr_indeksu,b);
                                                break;
                                            case 4:
                                                System.out.println("Wpisz stopień:");
                                                int stopien = scan.nextInt();
                                                System.out.println("Czy chcesz usunąć tą osobę z listy?\n1.tak\n2.nie");
                                                b=scan.nextInt();
                                                W.wyszukiwanieStudentaPoStopniu(listaOsob, stopien,b);
                                                break;
                                        }
                                    } else {
                                        System.out.println("Nieprawidlowy numer");
                                    }
                                } catch (InputMismatchException e) {
                                    System.out.println("NIE WPISAŁEŚ LICZBY CAŁKOWITEJ!!");
                                    System.exit(0);
                                }
                                break;
                            case 2:
                                try {
                                    System.out.println("WYBIERZ OPCJĘ WYSZUKIWANIA PRACOWNIKA:\n" +
                                            "1.po imieniu\n2.po nazwisku\n3.po wieku\n4.po stanowsku\n5. po liczbie nadgodzin\n6.po stażu");
                                    int wybor4 = scan.nextInt();
                                    if (wybor4 == 1 || wybor4 == 2 || wybor4 == 3 || wybor4 == 4 || wybor4 == 5 || wybor4 == 6) {
                                        switch (wybor4) {
                                            case 1:
                                                System.out.println("Wpisz imie:");
                                                String imie = scan.next();
                                                System.out.println("Czy chcesz usunąć tą osobę z listy?\n1.tak\n2.nie");
                                                int b=scan.nextInt();
                                                W.wyszukiwaniePracownikaPoImieniu(listaOsob, imie,b);
                                                break;
                                            case 2:
                                                System.out.println("Wpisz nazwisko:");
                                                String nazwisko = scan.next();
                                                System.out.println("Czy chcesz usunąć tą osobę z listy?\n1.tak\n2.nie");
                                                b=scan.nextInt();
                                                W.wyszukiwaniePracownikaPoNazwisku(listaOsob, nazwisko,b);
                                                break;
                                            case 3:
                                                System.out.println("Wprowadz wiek:");
                                                int wiek = scan.nextInt();
                                                System.out.println("Czy chcesz usunąć tą osobę z listy?\n1.tak\n2.nie");
                                                b=scan.nextInt();
                                                W.wyszukiwaniePracownikaPoWieku(listaOsob, wiek,b);
                                                break;
                                            case 4:
                                                System.out.println("Wprowadz stanowisko:");
                                                String stanowisko = scan.next();
                                                System.out.println("Czy chcesz usunąć tą osobę z listy?\n1.tak\n2.nie");
                                                b=scan.nextInt();
                                                W.wyszukiwaniePracownikaPoStanowisku(listaOsob, stanowisko,b);
                                                break;
                                            case 5:
                                                System.out.println("Wpisz liczbe nadgodzin:");
                                                int nadgodziny = scan.nextInt();
                                                System.out.println("Czy chcesz usunąć tą osobę z listy?\n1.tak\n2.nie");
                                                b=scan.nextInt();
                                                W.wyszukiwaniePracownikaPoNadgodzinach(listaOsob, nadgodziny,b);
                                                break;
                                            case 6:
                                                System.out.println("Wpisz staż: ");
                                                int staz = scan.nextInt();
                                                System.out.println("Czy chcesz usunąć tą osobę z listy?\n1.tak\n2.nie");
                                                b=scan.nextInt();
                                                W.wyszukiwaniePracownikaPoStazu(listaOsob, staz,b);
                                                break;
                                        }
                                    } else {
                                        System.out.println("Nieprawidlowy numer!");
                                    }
                                } catch (InputMismatchException e) {
                                    System.out.println("NIE WPISAŁEŚ LICZBY CAŁKOWITEJ!!");
                                }

                                break;
                            case 3:
                                try {
                                    System.out.println("WYBIERZ OPCJĘ WYSZUKIWANIA KURSÓW:\n1.po nazwie\n2.po prowadzacym\n3.po punktach ECTS");
                                    int wybor5 = scan.nextInt();
                                    if (wybor5 == 1 || wybor5 == 2 || wybor5 == 3) {
                                        switch (wybor5) {
                                            case 1:
                                                System.out.println("Wpisz nazwe kursu: ");
                                                String nazwa = scan.next();
                                                System.out.println("Czy chcesz usunąć ten kurs z listy?\n1.tak\n2.nie");
                                                int b=scan.nextInt();
                                                K.wyszukiwanieKursuPoNazwie(bazaKursow, nazwa,b);
                                                break;
                                            case 2:
                                                System.out.println("Wprowadz prowadzacego:");
                                                String prowadzacy = scan.next();
                                                System.out.println("Czy chcesz usunąć ten kurs z listy?\n1.tak\n2.nie");
                                                b=scan.nextInt();
                                                K.wyszukiwanieKursuPoProwadzacym(bazaKursow, prowadzacy,b);
                                                break;
                                            case 3:
                                                System.out.println("Wpisz liczbe ECTS: ");
                                                int ECTS = scan.nextInt();
                                                System.out.println("Czy chcesz usunąć ten kurs z listy?\n1.tak\n2.nie");
                                                b=scan.nextInt();
                                                K.wyszukiwanieKursuPoECTS(bazaKursow, ECTS,b);
                                                break;
                                        }
                                    } else {
                                        System.out.println("Nieprawidlowy numer!");
                                    }
                                } catch (InputMismatchException e) {
                                    System.out.println("NIE WPISAŁEŚ LICZBY CAŁKOWITEJ!!");
                                }


                                break;
                        }


                } catch (InputMismatchException e) {
                    System.out.println("NIE WPISAŁEŚ LICZBY CAŁKOWITEJ!!");
                }
               // i++;
           // }
        }


   /*   try{
          System.out.println("WYBIERZ OPCJĘ WYSZUKIWANIA STUDENTÓW:");
       int wybor3=scan.nextInt();
        String imieS="Jan";
        String nazwiskoS="Kowalski";
       // String nr_indeksu="255867";
        int stopien=1;
        String imieP="Mariusz";
        String nazwiskoP="Okoń";
        int wiek=48;
        String stanowisko="Referent";
        int nadgodziny=15;
        int staz=21;

        switch(wybor3){
            case 1:
                W.wyszukiwanieStudentaPoImieniu(listaOsob,imieS);
                break;
            case 2:
                W.wyszukiwanieStudentaPoNazwisku(listaOsob,nazwiskoS);
                break;
            case 3:
                W.wyszukiwanieStudentaPoNumerzeIndeksu(listaOsob);
                break;
            case 4:
                W.wyszukiwanieStudentaPoStopniu(listaOsob,stopien);
                break;
            case 5:
                W.wyszukiwaniePracownikaPoImieniu(listaOsob,imieP);
                break;
            case 6:
                W.wyszukiwaniePracownikaPoNazwisku(listaOsob,nazwiskoP);
                break;
            case 7:
                W.wyszukiwaniePracownikaPoWieku(listaOsob,wiek);
                break;
            case 8:
                W.wyszukiwaniePracownikaPoStanowisku(listaOsob,stanowisko);
                break;
            case 9:
                W.wyszukiwaniePracownikaPoNadgodzinach(listaOsob,nadgodziny);
                break;
            case 10:
                W.wyszukiwaniePracownikaPoStazu(listaOsob,staz);
                break;
        }
    }catch(InputMismatchException e){
        System.out.println("NIE WPISAŁEŚ LICZBY CAŁKOWITEJ!!");
    }

      try {
          System.out.println("WYBIERZ OPCJĘ WYSZUKIWANIA KURSÓW:");
          int wybor4 = scan.nextInt();
          String nazwa = "Algebra";
          String prowadzacy = "Karol Baranowski";
          int ECTS = 3;

          switch (wybor4) {
              case 1:
                  K.wyszukiwanieKursuPoNazwie(bazaKursow, nazwa);
                  break;
              case 2:
                  K.wyszukiwanieKursuPoProwadzacym(bazaKursow, prowadzacy);
                  break;
              case 3:
                  K.wyszukiwanieKursuPoECTS(bazaKursow, ECTS);
                  break;
          }
      }catch(InputMismatchException e){
          System.out.println("NIE WPISAŁEŚ LICZBY CAŁKOWITEJ!!");
      }

    }

    */


    }
}





