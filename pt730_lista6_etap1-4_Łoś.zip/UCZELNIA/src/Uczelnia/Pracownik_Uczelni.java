package Uczelnia;

import Osoba.Osoba;

public abstract class Pracownik_Uczelni extends Osoba {
    private String stanowisko;
    private int stazPracy;
    private double pensja;

    public Pracownik_Uczelni(String imie, String nazwisko, String PESEL, int wiek, String plec, String stanowisko, int stazPracy, double pensja) {
        super(imie, nazwisko, PESEL, wiek, plec);
        this.stanowisko = stanowisko;
        this.stazPracy = stazPracy;
        this.pensja = pensja;
    }

    public String getStanowisko() {
        return stanowisko;
    }

    public void setStanowisko(String stanowisko) {
        this.stanowisko = stanowisko;
    }

    public int getStazPracy() {
        return stazPracy;
    }

    public void setStazPracy(int stazPracy) {
        this.stazPracy = stazPracy;
    }

    public double getPensja() {
        return pensja;
    }

    public void setPensja(double pensja) {
        this.pensja = pensja;
    }
    public String toString(){
        return "Imie: "+getImie()+"\nNazwisko: "+getNazwisko()+"\nPESEL: "+getPESEL()+"\nWiek: "+getWiek()+"\nPłeć: "+getPlec()+"\nStanowisko:"+stanowisko+"\nStaż pracy: "+stazPracy+"\nPensja: "+pensja;
    }
}
