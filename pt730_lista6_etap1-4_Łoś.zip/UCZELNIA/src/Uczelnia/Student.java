package Uczelnia;

import Kursy.Kursy;
import Osoba.Osoba;

import java.util.ArrayList;

public class Student extends Osoba {
    private Kursy k1;
    private Kursy k2;
    private String numerIndeksu;
    private boolean czyERASMUS;
    private int stopien;
    private boolean stacjonarne;


    public Student(String imie, String nazwisko, String PESEL, int wiek, String plec, String numerIndeksu, boolean czyERASMUS,int stopien, boolean stacjonarne, Kursy k1,Kursy k2) {
        super(imie, nazwisko, PESEL, wiek, plec);
        this.numerIndeksu = numerIndeksu;
        this.czyERASMUS = czyERASMUS;
        this.stopien = stopien;
        this.stacjonarne = stacjonarne;
        this.k1=k1;
        this.k2=k2;
    }

    public String getNumerIndeksu() {
        return numerIndeksu;
    }

    public void setNumerIndeksu(String numerIndeksu) {
        this.numerIndeksu = numerIndeksu;
    }


    public boolean isCzyERASMUS() {
        return czyERASMUS;
    }

    public void setCzyERASMUS(boolean czyERASMUS) {
        this.czyERASMUS = czyERASMUS;
    }


    public boolean isStacjonarne() {
        return stacjonarne;
    }

    public void setStacjonarne(boolean stacjonarne) {
        this.stacjonarne = stacjonarne;
    }

    public int getStopien() {
        return stopien;
    }

    public void setStopien(int stopien) {
        this.stopien = stopien;
    }

    public Kursy getK1() {
        return k1;
    }

    public void setK(Kursy k1) {
        this.k1 = k1;
    }

    public Kursy getK2() {
        return k2;
    }

    public void setK2(Kursy k2) {
        this.k2 = k2;
    }

    public String toString(){
        System.out.println("----------------------------");
        System.out.println("STUDENT");
        return "Imie: "+getImie()+"\nNazwisko: "+getNazwisko()+"\nPESEL: "+getPESEL()+"\nWiek: "+getWiek()+"\nPłeć: "+getPlec()+"\nNumer indeksu: "+getNumerIndeksu()+"\nCzy jest na ERASMUSIE: "+czyERASMUS+"\nStopień: "+stopien+" \nDrugi stopień: "+" \nCzy stacjonarne: "+stacjonarne+"\nKursy: "+getK1()+getK2();
    }
}
